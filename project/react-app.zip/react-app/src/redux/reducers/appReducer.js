//src/redux/reducers/appReducers
const initialState = {
  brandList:[],
  productList:[],
  cartList:[],
  counter: 0
}

const reducer = (state=initialState, action) => {
  return state;
}

export default reducer;