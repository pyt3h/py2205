import axios from "axios";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {useSliceStore, useSliceSelector} from "utils/reduxHelper";
import Header from "components/Header";


function Payment() {
  const store = useSliceStore('app');
  const navigate = useNavigate(); 
  const {cartList} = useSliceSelector('app', ['cartList']);
  let total = 0;
  cartList.forEach(cart => total += cart.qty * cart.product.price);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [errors, setErrors] = useState({});

  async function init(){
    const token = localStorage.getItem('token');
    if(token){
      const {data} = await axios.get('/api/get-customer-info',{
        headers: {Authorization: "Bearer" + " " + token}
      });
      setName(data.name);
      setPhone(data.phone);
      setAddress(data.address);
      setCustomerId(data.id);
    }
  }

  useEffect(() => {init()}, []);
  
  async function purchase(){
    const items = cartList.map(cart => ({
      qty: cart.qty,
      product_id: cart.product.id
    }));
    const data = {
      customer_name: name,
      customer_phone: phone,
      customer_address: address,
      customer_id: customerId,
      items: items
    };

    console.log('data=', JSON.stringify(data));
    
    setErrors({});    // clear errors;

    try{
      await axios.post('/api/purchase', data);
      navigate('/success');
      store.setState({cartList: []});   // clear cart
    }catch(e){
      console.log(e.response.data);
      setErrors(e.response.data);
    }
  }

  return (
    <>
      <Header/>
      <div className="container mt-5 mb-5">
        <div className="row">
          <div className="col">
            <div className="card">
              <div className="content-body">
                <h4 className="card-title mb-4">Cart Review</h4>

                {cartList.map((cart, index) =>
                  <div className="row gy-3 mb-4">
                    <div className="col-lg-5">
                      <div className="itemside me-lg-5">
                        <div className="aside">
                          <img alt=""
                            src={axios.defaults.baseURL + cart.product.image}
                            className="img-sm img-thumbnail"
                          />
                        </div>
                        <div className="info">
                          <a href="#/" className="title">
                            {cart.product.name}
                          </a>
                          <p className="text-muted"> Medium Size </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-auto">
                      <input
                        style={{width: "100px"}}
                        className="form-control"
                        readOnly={true}
                        value={cart.qty}
                      />
                    </div>
                    <div className="col-lg-2 col-sm-4 col-6">
                      <div className="price-wrap lh-sm">
                        <var className="price h6">${(cart.qty*cart.product.price).toFixed(2)}</var> <br />
                        <small className="text-muted"> ${cart.product.price.toFixed(2)} / per item </small>
                      </div>
                    </div>
                  </div>
                )}
                <h5>Total: ${total.toFixed(2)}</h5>
              </div>
            </div>

            <div className="card mt-3">
              <div className="content-body">
                <h4 className="card-title"> Shipping info </h4>
                <div className="row">
                  <div className="col-6 mb-3">
                    <label for="" className="form-label">
                      Name
                    </label>
                    <input type="text" className="form-control" 
                      value={name} onChange={e => setName(e.target.value)}
                    />
                    {errors.customer_name}
                  </div>

                  <div className="col-6 mb-3">
                    <label for="" className="form-label">
                      Phone
                    </label>
                    <input type="text" className="form-control"
                      value={phone} onChange={e => setPhone(e.target.value)}
                    />
                    {errors.customer_phone}
                  </div>
                </div>

                <div className="mb-4">
                  <label for="" className="form-label">
                    Address
                  </label>
                  <textarea className="form-control"
                    value={address} onChange={e => setAddress(e.target.value)}
                  ></textarea>
                  {errors.customer_address}
                </div>
              </div>
            </div>

            <div className="card mt-3">
              <div className="card-body">
                <h4 className="card-title">Payment method</h4>
                <div className="card">
                  <div className="card-header">
                    <input type="radio" name="payment_method" className="me-1" />{" "}
                    Cash on Delivery
                  </div>
                </div>
                <div className="card mt-2">
                  <div className="card-header">
                    <input type="radio" name="payment_method" className="me-1" />{" "}
                    Credit card
                  </div>
                  <div className="card-body">
                    <div className="row g-2">
                      <div className="col-sm-4">
                        <label className="form-label">Card number</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="xxxx-xxxx-xxxx-xxxx"
                        />
                      </div>
                      <div className="col-sm-3">
                        <label className="form-label">Expiry date</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="dd/yy"
                        />
                      </div>
                      <div className="col-sm-2">
                        <label className="form-label">CVV</label>
                        <input
                          type="text"
                          className="form-control"
                          placeholder="cvc"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <button onClick={purchase} className="mt-3 btn btn-primary">
              Make Purchase
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default Payment;
