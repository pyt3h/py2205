import axios from "axios";
import { useState } from "react";


function Signin() {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  async function signin(event){
    event.preventDefault(); // prevent page reload
    try{
      const resp = await axios.post('/api/token', {username: phone, password});
      localStorage.setItem('token', resp.data.access);
      window.location.href = '/';
    }catch{
      setError("Invalid credentials");
    }
  }
  return (
    <div className="container">
      <div className="card shadow mx-auto"
        style={{ maxWidth: "400px", marginTop: "80px" }} >
        <div className="card-body">
          <h4 className="card-title mb-4">Sign in</h4>
          <form onSubmit={signin}>
            <div className="mb-3">
              <label className="form-label">Phone</label>
              <input className="form-control" placeholder="Phone" type="text" 
                value={phone} onChange={e => setPhone(e.target.value)}
              />
            </div>

            <div className="mb-4">
              <label className="form-label">Password</label>
              <input className="form-control" type="password" 
                value={password} onChange={e => setPassword(e.target.value)}
              />
            </div>
            <div className="mb-3">
              {error}
            </div>
            <div className="mb-4">
              <button type="submit" className="btn btn-primary w-100"> Login </button>
            </div>
          </form>
          <hr />
          <p className="text-center mb-2">Do not have an account? <a href="signup.html">Sign up</a></p>
        </div>
      </div>
    </div>
  );
}

export default Signin;