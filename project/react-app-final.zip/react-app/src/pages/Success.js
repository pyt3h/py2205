import { Link } from "react-router-dom";
import Header from "components/Header";
function Success() {
  return (
    <>
      <Header/>

      <div className="container mt-5 mb-5">
        <div className="row">
          <div className="col">
            <h5 className="text-success">Your purchase has been success!</h5>
          </div>
        </div>
        <Link to="/" className="mt-3 btn btn-primary">
          Continue shopping
        </Link>
      </div>
    </>
  );
}

export default Success;
