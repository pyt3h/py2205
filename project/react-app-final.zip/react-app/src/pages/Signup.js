import axios from "axios";
import { useState } from "react";

function Signup() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [errors, setErrors] = useState({});

  async function signup(event){
    event.preventDefault(); // prevent page reload
    const data = {
      name, phone, address, password, password2
    };
    setErrors({});  // clear errors
    try{
      await axios.post('/api/create-customer', data);
      //  created user successfully
      const resp = await axios.post('/api/token', {username: phone, password});
      localStorage.setItem('token', resp.data.access);
      window.location.href = '/';
    }catch(e){
      console.log(e.response.data);
      setErrors(e.response.data);
    }
  }
  return (
    <div className="container">
      <div
        className="card shadow mx-auto"
        style={{
          maxWidth: "400px",
          marginTop:"80px",
          marginBottom: "80px"
        }}
      >
        <div className="card-body">
          <h4 className="card-title mb-4">Sign up</h4>
          <form onSubmit={signup}>
            <div className="row gx-2">
              <div className="col mb-3">
                <label className="form-label">Name</label>
                <input type="text" className="form-control" 
                  value={name} onChange={e => setName(e.target.value)}
                /> 
                {errors.name}
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">Phone</label>
              <div className="row gx-2">
                <div className="col">
                  <input className="form-control" placeholder="Phone" type="text" 
                    value={phone} onChange={e => setPhone(e.target.value)}
                  /> 
                  {errors.phone}
                </div>
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">Address</label>
              <div className="row gx-2">
                <div className="col">
                  <textarea
                    className="form-control"
                    placeholder="Address"
                    value={address} onChange={e => setAddress(e.target.value)}
                  ></textarea>
                  {errors.address}
                </div>
              </div>
            </div>
            <div className="mb-3">
              <label className="form-label">Password</label>
              <input
                className="form-control"
                placeholder="At least 6 characters."
                type="password"
                value={password} onChange={e => setPassword(e.target.value)}
              />
              {errors.password}
            </div>
            <div className="mb-3">
              <label className="form-label">Repeat password</label>
              <input className="form-control" placeholder="" type="password" 
                value={password2} onChange={e => setPassword2(e.target.value)}
              />
              {errors.password2}
            </div>
            <div className="mb-4">
              <button type="submit" className="btn btn-primary w-100">
                {" "}
                Sign up{" "}
              </button>
            </div>
          </form>
          <hr />
          <p className="text-center mb-2">
            Already have account?
            <a href="signin.html">Sign in</a>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Signup;
