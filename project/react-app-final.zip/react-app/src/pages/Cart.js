import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import {useSliceStore, useSliceSelector} from "utils/reduxHelper";
import Header from "components/Header";

function Cart() {
  const store = useSliceStore('app');
  const navigate = useNavigate(); 
  const {cartList} = useSliceSelector('app', ['cartList']);
  let total = 0;
  cartList.forEach(cart => total += cart.qty * cart.product.price);

  function updateCart(index, qty){
    const newCartList = cartList.map(cart => ({...cart})); //deep copy
    newCartList[index].qty = parseInt(qty);
    store.setState({cartList: newCartList});
  }

  function removeCart(index){
    const newCartList = cartList.map(cart => ({...cart})); //deep copy
    newCartList.splice(index, 1); // remove item at index
    store.setState({cartList: newCartList});
    if(newCartList.length === 0){  // cart is empty
      navigate('/');               // redirect to home page
    }
  }

  return (
    <>
      <Header/>
      <div className="container mt-5 mb-5">
        <div className="row">
          <div className="col">
            <div className="card">
              <div className="content-body">
                <h4 className="card-title mb-4">Your shopping cart</h4>
                {cartList.map((cart, index) =>
                  <div className="row gy-3 mb-4">
                    <div className="col-lg-5">
                      <div className="itemside me-lg-5">
                        <div className="aside">
                          <img alt=""
                            src={axios.defaults.baseURL + cart.product.image}
                            className="img-sm img-thumbnail"
                          />
                        </div>
                        <div className="info">
                          <a href="#/" className="title">
                            {cart.product.name}
                          </a>
                          <p className="text-muted"> Medium Size </p>
                        </div>
                      </div>
                    </div>
                    <div className="col-auto">
                      <input
                        style={{width: "100px"}}
                        className="form-control"
                        type="number"
                        min="1"
                        value={cart.qty}
                        onChange={e => updateCart(index, e.target.value)}
                      />
                    </div>
                    <div className="col-lg-2 col-sm-4 col-6">
                      <div className="price-wrap lh-sm">
                        <var className="price h6">${(cart.qty*cart.product.price).toFixed(2)}</var> <br />
                        <small className="text-muted"> ${cart.product.price.toFixed(2)} / per item </small>
                      </div>
                    </div>
                    <div className="col-lg col-sm-4">
                      <div className="float-lg-end">
                        <a onClick={() => removeCart(index)} href="#/" className="btn btn-light text-danger">
                          {" "}
                          Remove
                        </a>
                      </div>
                    </div>
                  </div>
                )}
                <h5>Total: ${total.toFixed(2)}</h5>
              </div>
            </div>

            <Link to="/payment" className="mt-3 btn btn-primary">
              Continue
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default Cart;
