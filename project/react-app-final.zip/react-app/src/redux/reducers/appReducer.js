//src/redux/reducers/appReducers
const initialState = {
  brandList:[],
  productList:[],
  cartList:[],
  counter: 0,

  // search params
  minPrice: '',
  maxPrice: '',
  keyword: '',
  brandIds: []
}

const reducer = (state=initialState, action) => {
  return state;
}

export default reducer;